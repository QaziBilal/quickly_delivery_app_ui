import 'package:flutter/material.dart';

import 'src/Myapp.dart';

void main() {
  runApp(const MyApp());
}

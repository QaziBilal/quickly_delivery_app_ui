const String imagepath = "assets/images";

const String klogo = "$imagepath/logo final.png";
const String kimage = "$imagepath/download.jpg";
const String kprofile = "$imagepath/profile.jpg";
const String kbanner = "$imagepath/banner.png";
const String kmap = "$imagepath/map.png";

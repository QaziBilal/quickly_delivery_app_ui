import 'package:flutter/material.dart';

import 'colors.dart';

TextStyle ktextstyle = TextStyle(fontFamily: "SEGOEUI", color: kcolorwhite);

import 'package:flutter/material.dart';

Color kcolorblue = const Color(0xff5DFAE0);

Color kcolorpurple = const Color(0xffA762D6);

Color kcolorblack = const Color(0xff000000);
Color kcolorwhite = const Color(0xffffffff);

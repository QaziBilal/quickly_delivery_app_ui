import 'package:flutter/material.dart';
import 'package:quickly_delivery_man/src/utils/icons.dart';
import 'package:quickly_delivery_man/src/utils/images.dart';
import 'package:quickly_delivery_man/src/utils/text_style.dart';
import 'package:quickly_delivery_man/src/views/Auth/signup_screen.dart';
import 'package:quickly_delivery_man/src/views/delivery_man/personal_info.dart';
import 'package:quickly_delivery_man/src/views/main_page.dart';
import 'package:quickly_delivery_man/src/widgets/bottom_social_login.dart';
import 'package:quickly_delivery_man/src/widgets/custom_button.dart';
import 'package:quickly_delivery_man/src/widgets/custom_container.dart';
import 'package:quickly_delivery_man/src/widgets/custom_image.dart';
import 'package:quickly_delivery_man/src/widgets/text_field.dart';

import '../../utils/colors.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});

  final TextEditingController loginController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    double sw = MediaQuery.sizeOf(context).width;
    double sh = MediaQuery.sizeOf(context).height;
    return Scaffold(
      backgroundColor: kcolorblack,
      body: SafeArea(
          child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned.fill(child: loginPage(sw, sh, context)),
          Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: socialMediaBottomLogin(sw, sh))
        ],
      )),
    );
  }

  Widget loginPage(sw, sh, context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: sh * 0.1,
          ),
          customImage(klogo, sw * 0.7, sh * 0.1, BoxFit.contain),
          SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomContainer(
                paddingbottom: 10,
                paddingtop: 10,
                paddingleft: 15,
                paddingright: 15,
                marginleft: 25,
                marginright: 25,
                child: Row(
                  children: [
                    Image.asset(
                      kIconEnglish,
                      width: 18,
                      height: 18,
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    Text(
                      "English",
                      style: ktextstyle.copyWith(
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              CustomContainer(
                paddingbottom: 10,
                paddingtop: 10,
                paddingleft: 15,
                paddingright: 15,
                marginleft: 25,
                marginright: 25,
                child: Row(
                  children: [
                    Text(
                      "عربي",
                      style: ktextstyle.copyWith(fontSize: 14),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    Image.asset(
                      kIconArabic,
                      width: 18,
                      height: 18,
                    ),
                  ],
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Align(
              alignment: Alignment.bottomLeft,
              child: Text(
                "Phone Number",
                style: ktextstyle.copyWith(fontSize: 14),
              ),
            ),
          ),
          CustomContainer(
            marginright: 20,
            marginleft: 20,
            paddingleft: 15,
            child: CustomTextFeild(
              controller: loginController,
              prefixIcon: kIconMobile,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Align(
              alignment: Alignment.bottomLeft,
              child: Text(
                "Password",
                style: ktextstyle.copyWith(fontSize: 14),
              ),
            ),
          ),
          CustomContainer(
            marginright: 20,
            marginleft: 20,
            paddingleft: 15,
            child: CustomTextFeild(
              controller: passwordController,
              prefixIcon: kIconLock,
              suffixIcon: kIconEye,
              width: 5,
              height: 5,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20, top: 10),
            child: Align(
              alignment: Alignment.bottomRight,
              child: Text(
                "Forgot Password?",
                style: ktextstyle.copyWith(fontSize: 14),
              ),
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => MainScreen(currentindex: 1)));
            },
            child: CustomButton(
                paddingbottom: 15,
                paddingright: 15,
                width: sw * 0.5,
                text: "LOGIN"),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Text(
              "By continuing, you agree to accept our Privacy Policy & Terms of Service.",
              style: ktextstyle.copyWith(letterSpacing: 0.6, fontSize: 15),
              textAlign: TextAlign.center,
            ),
          ),
          Text(
            "Don't  Have An Account ?",
            style: ktextstyle.copyWith(letterSpacing: 0.6, fontSize: 15),
            textAlign: TextAlign.center,
          ),
          SizedBox(
            height: 20,
          ),
          InkWell(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SignupScreen()));
            },
            child: CustomButton(
                paddingbottom: 15,
                paddingright: 15,
                width: sw * 0.5,
                text: "SIGNUP"),
          ),
          SizedBox(
            height: 20,
          ),
          InkWell(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => DeliveryManScreen()));
            },
            child: CustomButton(
                paddingbottom: 15,
                paddingright: 15,
                width: sw * 0.5,
                text: "JOIN AS DELIVERY"),
          ),
          Text(
            "OR",
            style: ktextstyle.copyWith(letterSpacing: 0.6, fontSize: 15),
            textAlign: TextAlign.center,
          ),
          if (sw >= 450 || sh >= 300)
            SizedBox(
              height: sh * 0.3,
            ),
        ],
      ),
    );
  }
}
